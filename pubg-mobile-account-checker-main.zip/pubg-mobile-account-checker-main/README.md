Checks account accuracy for pubg mobile. It needs a proxy to work.
Install python and node js.

## Setup
- Fill proxies.txt in given format.
- Open terminal/cmd in folder. 
- `pip install -r requirements.txt`
- `npm i`

## Run
- `node run.js account_list.txt BROWSER-COUNT PAGE-COUNT`
  or
- `node run.js combo_list.txt`
  or
- `node run.js combo_list.txt 2 10`
  
